Video explicativo

https://www.youtube.com/watch?v=KKzFmkWaIhE&t=323s